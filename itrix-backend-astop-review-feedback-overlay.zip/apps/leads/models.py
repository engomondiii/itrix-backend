"""
Lead models — the core CRM record.

``Lead`` is created when a visitor completes the review (qualify). It stores the
qualification answers, the authoritative score breakdown + tier, the routed product /
license pathway, the AI-generated bottleneck summary and next step, ownership, status,
special rights, and SLA fields.

Enum design (Backend v3) and the dashboard contract:

* **Status (12)** — the dashboard renders/filters by display-label strings
  ("New", "Contacted", …), so we store those labels. v3 expands the dashboard's 8 to
  12 by adding intermediate operational states; the 8 dashboard values are a subset, so
  the dashboard keeps working and the extra states are available to the backend/pipeline.
* **SpecialRights (7)** — dashboard's 5 + 2 (v3). Stored as display labels.
* **LeadActivity types (11)** — dashboard's 10 (incl. ``meeting``) + ``paid_eval`` companion.
* **product_route / commercial_path** — stored as canonical codes
  (``alpha_compute`` / ``non_exclusive`` …) and serialized to the dashboard's display
  strings ("ALPHA Compute" / "Non-Exclusive") by the serializer.
"""

from __future__ import annotations

from django.conf import settings
from django.db import models

from apps.core.models import BaseModel


class LeadSource(models.TextChoices):
    """
    How this SUBJECT entered the system (v7.2, Architecture v2.9 §15.7).

    `conversation` is the default and the historical case: somebody described a problem and
    Layer 1 qualified them. `self_serve` is new with open registration — somebody arrived,
    opened a workspace, and may not have said anything yet.

    R70: a self-serve subject with no turns is NOT A LEAD. It is excluded from every queue,
    tier count, conversion rate and SLA clock, and appears in one dashboard segment instead.
    Counting it would corrupt the exact metrics Layer 1 exists to produce.
    """

    CONVERSATION = "conversation", "Conversation"
    SELF_SERVE = "self_serve", "Self-serve registration"
    IMPORTED = "imported", "Imported"


class LeadStatus(models.TextChoices):
    """12 lifecycle statuses. The first 8 match the dashboard's pipeline columns."""

    NEW = "New", "New"
    CONTACTED = "Contacted", "Contacted"
    MEETING_BOOKED = "Meeting Booked", "Meeting Booked"
    NDA = "NDA", "NDA"
    EVALUATION = "Evaluation", "Evaluation"
    POC = "PoC", "PoC"
    LICENSED = "Licensed", "Licensed"
    CLOSED = "Closed", "Closed"
    # ── v3 additional operational states ─────────────────────────────────────
    QUALIFYING = "Qualifying", "Qualifying"
    NURTURE = "Nurture", "Nurture"
    NEGOTIATION = "Negotiation", "Negotiation"
    LOST = "Lost", "Lost"


class SpecialRights(models.TextChoices):
    """7 reserved-rights types. The first 5 match the dashboard."""

    NONE = "None", "None"
    FIELD = "Field", "Field"
    TERRITORY = "Territory", "Territory"
    PRODUCT_CATEGORY = "Product-Category", "Product-Category"
    ACQUISITION = "Acquisition", "Acquisition"
    # ── v3 additional ────────────────────────────────────────────────────────
    EXCLUSIVE_GLOBAL = "Exclusive-Global", "Exclusive-Global"
    TIME_LIMITED = "Time-Limited", "Time-Limited"


class ProductRouteCode(models.TextChoices):
    ALPHA_COMPUTE = "alpha_compute", "ALPHA Compute"
    ALPHA_CORE = "alpha_core", "ALPHA Core"
    BOTH = "both", "Both"
    GENERAL = "general", "General"


class CommercialStage(models.TextChoices):
    DISCOVERY = "discovery", "Discovery"
    SALES_PLATFORM = "sales_platform", "AI-Powered Sales Platform"
    ASTOP = "astop", "ASTOP"
    ALPHA_COMPUTE = "alpha_compute", "ALPHA Compute"
    ALPHA_CORE = "alpha_core", "ALPHA Core"


class TrustStatus(models.TextChoices):
    UNREVIEWED = "unreviewed", "Unreviewed"
    PASS = "pass", "Pass"
    REVIEW = "review", "Human review"
    REJECT = "reject", "Sensitive access blocked"


class CommercialPathCode(models.TextChoices):
    NON_EXCLUSIVE = "non_exclusive", "Non-Exclusive"
    EXCLUSIVE = "exclusive", "Exclusive"
    STRATEGIC = "strategic", "Strategic"
    NONE = "none", "None"


# Display-label maps used by serializers (code -> dashboard display string).
PRODUCT_ROUTE_DISPLAY = {
    "alpha_compute": "ALPHA Compute",
    "alpha_core": "ALPHA Core",
    "both": "Both",
    "general": "ALPHA Compute",  # general surfaces as Compute-leaning in the dashboard
}
COMMERCIAL_PATH_DISPLAY = {
    "non_exclusive": "Non-Exclusive",
    "exclusive": "Exclusive",
    "strategic": "Strategic",
    "none": "Non-Exclusive",
    "": "Non-Exclusive",
}

TERMINAL_STATUSES = {LeadStatus.LICENSED, LeadStatus.CLOSED, LeadStatus.LOST}


class Lead(BaseModel):
    """A qualified lead in the CRM."""

    # ── Link back to the originating review/visitor ──────────────────────────
    review_session = models.ForeignKey(
        "review.ReviewSession",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="leads",
    )
    client_id = models.CharField(max_length=128, blank=True, default="", db_index=True)

    # ── Contact / identity (filled progressively; email may arrive via capture) ─
    visitor_name = models.CharField(max_length=200, blank=True, default="")
    company = models.CharField(max_length=200, blank=True, default="")
    # v7.2 — provenance. INTERNAL-ONLY (§10.5): a fact about how we acquired somebody.
    lead_source = models.CharField(
        max_length=16,
        choices=LeadSource.choices,
        default=LeadSource.CONVERSATION,
        db_index=True,
    )
    email = models.EmailField(blank=True, default="", db_index=True)
    industry = models.CharField(max_length=120, blank=True, default="")
    role = models.CharField(max_length=120, blank=True, default="")
    # v2.3/v3.5 commercial qualification. These facts are deliberately separate
    # from account identity and from the 10-state relationship ladder.
    legal_entity = models.CharField(max_length=255, blank=True, default="")
    corporate_domain = models.CharField(max_length=255, blank=True, default="")
    business_unit = models.CharField(max_length=255, blank=True, default="")
    sponsor = models.CharField(max_length=255, blank=True, default="")
    acquisition_context = models.JSONField(default=dict, blank=True)
    trust_screening = models.JSONField(default=dict, blank=True)
    trust_status = models.CharField(max_length=16, choices=TrustStatus.choices, default=TrustStatus.UNREVIEWED, db_index=True)
    current_marketing_stage = models.CharField(max_length=24, choices=CommercialStage.choices, default=CommercialStage.DISCOVERY, db_index=True)
    commercial_progress = models.JSONField(default=dict, blank=True)

    # ── Routing ──────────────────────────────────────────────────────────────
    product_route = models.CharField(
        max_length=20, choices=ProductRouteCode.choices, default=ProductRouteCode.GENERAL
    )
    commercial_path = models.CharField(
        max_length=20, choices=CommercialPathCode.choices, default=CommercialPathCode.NONE
    )
    special_rights = models.CharField(
        max_length=40, choices=SpecialRights.choices, default=SpecialRights.NONE
    )

    # ── Problem framing ──────────────────────────────────────────────────────
    compute_bottleneck = models.TextField(
        blank=True, default="", help_text="AI-generated summary of the bottleneck."
    )
    primary_pain = models.CharField(max_length=120, blank=True, default="")
    workload_type = models.CharField(max_length=120, blank=True, default="")
    current_stack = models.JSONField(default=list, blank=True)
    commercial_intent = models.CharField(max_length=120, blank=True, default="")
    timeline = models.CharField(max_length=120, blank=True, default="")

    # ── Scoring ──────────────────────────────────────────────────────────────
    score = models.PositiveSmallIntegerField(default=0)
    tier = models.PositiveSmallIntegerField(default=4)
    score_breakdown = models.JSONField(default=dict, blank=True)
    recommended_next_step = models.TextField(blank=True, default="")
    human_handoff_trigger = models.BooleanField(default=False)

    # ── Qualification answers (Q1–Q9 raw) ────────────────────────────────────
    qualification = models.JSONField(default=dict, blank=True)

    # ── Workflow / ownership ─────────────────────────────────────────────────
    status = models.CharField(
        max_length=20, choices=LeadStatus.choices, default=LeadStatus.NEW, db_index=True
    )
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="owned_leads",
    )

    # ── Engagement signals ───────────────────────────────────────────────────
    cta_clicked = models.CharField(max_length=120, blank=True, default="")
    documents_viewed = models.PositiveIntegerField(default=0)

    # ── SLA fields ───────────────────────────────────────────────────────────
    sla_response_due_at = models.DateTimeField(null=True, blank=True)
    first_response_at = models.DateTimeField(null=True, blank=True)
    escalated = models.BooleanField(default=False)
    escalated_at = models.DateTimeField(null=True, blank=True)

    # ── v4.0 journey state machine + client link (Backend v4 §3.2) ───────────
    # The authoritative journey state lives here; transitions go through
    # apps.journey.services.advance.advance() — never set directly in a view.
    journey_state = models.CharField(
        max_length=20,
        default="ARRIVED",
        db_index=True,
        help_text="Progressive-disclosure state (apps.journey.JourneyState).",
    )
    # 1:1 to the account-holding Client is the REVERSE side of clients.Client.lead
    # (access as ``lead.client_account``). We intentionally do NOT add a forward
    # ``client`` field here because ``client_id`` already exists on Lead (the visitor's
    # anonymous client id from Surface 1) and would clash.
    # Timestamp the moment value was delivered (reaching DIAGNOSED). Value-first
    # enforcement: a commitment ask is only allowed once this is set.
    value_delivered_at = models.DateTimeField(null=True, blank=True)
    # Audit of the most recent gate decision (deterministic gates, §3.3).
    gate_decision = models.CharField(max_length=16, blank=True, default="")
    gate_decision_reason = models.CharField(max_length=255, blank=True, default="")

    # ── v6.0: denormalised ladder position ───────────────────────────────────
    # ``journey_state`` remains authoritative and has exactly one writer
    # (journey.advance). These two are DERIVED and kept in lockstep by advance() so no
    # reader has to recompute them and no report has to hard-code the ladder order.
    # journey_number is NULL for DORMANT, which is off-ladder by design.
    journey_number = models.PositiveSmallIntegerField(null=True, blank=True, db_index=True)
    state_key = models.CharField(max_length=20, blank=True, default="", db_index=True)

    # The persona hypothesis. NULLABLE and INTERNAL-ONLY: it is on the §10.5 list of
    # fields that must not appear on the anonymous or client plane, at any state.
    # A match changes which pitch room renders; it never becomes a sentence.
    persona = models.ForeignKey(
        "personas.Persona",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="leads",
    )

    # The thread this lead was born in — the conversation they started as a visitor.
    first_thread = models.ForeignKey(
        "conversations.Thread",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="originated_leads",
    )
    # Count only. The attachments themselves are thread-scoped and never lead-scoped.
    attachment_count = models.PositiveIntegerField(default=0)

    submitted_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-submitted_at"]
        verbose_name = "Lead"
        verbose_name_plural = "Leads"
        indexes = [
            models.Index(fields=["tier", "status"]),
            models.Index(fields=["status", "submitted_at"]),
            models.Index(fields=["owner", "status"]),
            models.Index(fields=["journey_state"]),
            models.Index(fields=["journey_number"]),
        ]

    def __str__(self) -> str:
        who = self.company or self.visitor_name or self.email or "lead"
        return f"Lead({who}, T{self.tier}, {self.status})"

    @property
    def is_open(self) -> bool:
        return self.status not in TERMINAL_STATUSES

    @property
    def product_route_display(self) -> str:
        return PRODUCT_ROUTE_DISPLAY.get(self.product_route, "ALPHA Compute")

    @property
    def commercial_path_display(self) -> str:
        return COMMERCIAL_PATH_DISPLAY.get(self.commercial_path, "Non-Exclusive")


class ASTOPStage(models.TextChoices):
    IDENTIFY_QUALIFY = "identify_qualify", "Identify & Qualify"
    NDA_BRIEFING = "nda_briefing", "NDA & Briefing"
    CONTROLLED_EVALUATION = "controlled_evaluation", "Controlled Evaluation"
    LO_DEPLOYMENT = "lo_deployment", "License-Out & Deployment"
    VERIFY_EXPAND = "verify_expand", "Verify & Expand"
    CLOSED = "closed", "Closed"


class ASTOPEngagement(BaseModel):
    """Controlled ASTOP commercial/proof record attached to the existing Lead.

    It is intentionally not another CRM or relationship ladder: Lead/journey remain
    authoritative for the relationship. This record owns only ASTOP-specific
    qualification, attributable evaluation, License-Out entitlement and verified value.
    """

    lead = models.OneToOneField(Lead, on_delete=models.CASCADE, related_name="astop_engagement")
    stage = models.CharField(max_length=32, choices=ASTOPStage.choices, default=ASTOPStage.IDENTIFY_QUALIFY, db_index=True)
    qualification_context = models.JSONField(default=dict, blank=True)
    evaluation_agreement = models.CharField(max_length=255, blank=True, default="")
    evaluation_scope = models.JSONField(default=dict, blank=True)
    baseline = models.JSONField(default=dict, blank=True)
    decision_fidelity = models.JSONField(default=dict, blank=True)
    measured_savings = models.JSONField(default=dict, blank=True)
    estimated_savings = models.JSONField(default=dict, blank=True)
    evaluation_result = models.JSONField(default=dict, blank=True)
    security_result = models.JSONField(default=dict, blank=True)
    integration_feasibility = models.JSONField(default=dict, blank=True)
    controlled_build_id = models.CharField(max_length=255, blank=True, default="")
    attribution_id = models.CharField(max_length=255, blank=True, default="")
    lo_scope = models.JSONField(default=dict, blank=True)
    lo_executed_at = models.DateTimeField(null=True, blank=True)
    entitlement_status = models.CharField(max_length=32, blank=True, default="")
    entitlement_expires_at = models.DateTimeField(null=True, blank=True)
    revocation_status = models.CharField(max_length=32, blank=True, default="")
    authorized_install_at = models.DateTimeField(null=True, blank=True)
    reproducible_value_at = models.DateTimeField(null=True, blank=True)
    verified_value = models.JSONField(default=dict, blank=True)
    expansion = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-updated_at"]

    @property
    def ttfv_seconds(self):
        if not self.authorized_install_at or not self.reproducible_value_at:
            return None
        delta = self.reproducible_value_at - self.authorized_install_at
        return max(0, int(delta.total_seconds()))

    @property
    def has_verified_value(self) -> bool:
        return bool(self.verified_value) and self.stage == ASTOPStage.VERIFY_EXPAND


class LeadNote(BaseModel):
    """An internal note attached to a lead."""

    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="notes")
    body = models.TextField()
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="lead_notes",
    )
    author_name = models.CharField(max_length=200, blank=True, default="")

    class Meta:
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return f"LeadNote({self.lead_id})"


class LeadMeeting(BaseModel):
    """A meeting scheduled with a lead (captured by the Book meeting flow)."""

    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="meetings")
    scheduled_at = models.DateTimeField()
    duration_mins = models.PositiveIntegerField(default=30)
    attendee = models.CharField(max_length=200, blank=True, default="")
    location = models.CharField(max_length=500, blank=True, default="")
    notes = models.TextField(blank=True, default="")
    booked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="booked_meetings",
    )
    booked_by_name = models.CharField(max_length=200, blank=True, default="")

    class Meta:
        ordering = ["-scheduled_at"]

    def __str__(self) -> str:
        return f"LeadMeeting({self.lead_id}, {self.scheduled_at})"


class LeadActivity(BaseModel):
    """A timeline entry for a lead. 11 activity types (Backend v3)."""

    class ActivityType(models.TextChoices):
        SUBMISSION = "submission", "Submission"
        STATUS_CHANGE = "status_change", "Status change"
        OWNER_CHANGE = "owner_change", "Owner change"
        NOTE = "note", "Note"
        EMAIL_SENT = "email_sent", "Email sent"
        ESCALATED = "escalated", "Escalated"
        NDA = "nda", "NDA"
        EVALUATION = "evaluation", "Evaluation"
        POC = "poc", "PoC"
        PAID_EVAL = "paid_eval", "Paid evaluation"
        MEETING = "meeting", "Meeting"

    lead = models.ForeignKey(Lead, on_delete=models.CASCADE, related_name="activities")
    type = models.CharField(max_length=20, choices=ActivityType.choices)
    label = models.CharField(max_length=255)
    by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="lead_activities",
    )
    by_name = models.CharField(max_length=200, blank=True, default="")
    meta = models.JSONField(default=dict, blank=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name_plural = "Lead activities"

    def __str__(self) -> str:
        return f"LeadActivity({self.type}, {self.lead_id})"
