# itriX Backend Fix v4.0.4 — instant /c/[token] (no more 44s spinner)

## Symptom
The /c/[token] page sat on the "preparing" spinner for a long time. `curl` to
`/client-page/{token}` measured ~44s.

## Root cause
`build_client_page` (the client-page GET handler) ran TWO live Claude calls synchronously
on every page load:
1. `generate_for_lead` (if the background build hadn't finished) → Diagnosis agent
   (OpenAI embed + Pinecone + Claude).
2. `_build_pitch` → the Pitch agent → another Claude call.
Stacked, that's ~44s — so the page blocked until both returned.

## The fix (1 file: apps/result_page/services/result_generator.py)
The client-page GET path is now **AI-free and instant**:
- `generate_for_lead` gains a `use_ai` flag (default True). The GET path calls it with
  `use_ai=False` → builds the deterministic page instantly if none exists yet.
- `_build_pitch` uses the **deterministic** pitch room on the GET path (no live Claude
  call). It's claim-safe and structurally identical.
- The AI-enriched page is still produced in the **background** from qualification
  (`generate_for_lead(lead)` with the default `use_ai=True`), so a later load / refresh
  shows the enriched narrative. Best of both: instant page + AI enrichment behind it.

## Apply
```bash
cd /path/to/itrix-backend
unzip -o itrix-backend-fix.zip -d /tmp/befix
bash /tmp/befix/backend_fix/APPLY_BACKEND_FIX.sh
```
Restart the backend after.

## Verified
- Client-page fetch with AI ON but providers unreachable: **0.02s** (was 44s), HTTP 200,
  full diagnosis rows + pitch slides present.
- Django `check` clean under development and production settings.
- Background AI build from qualify unchanged (still `use_ai=True`).
