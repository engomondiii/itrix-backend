# itriX backend — fix set, 2026-08-12

Seven reported defects. 17 files: **15 modified, 2 new test modules**. No migrations —
nothing in this set changes a model.

## Install

From the **root of the itrix-backend repo**, in PowerShell:

```powershell
Expand-Archive .\itrix-backend-fixes-aug12.zip -DestinationPath . -Force
powershell -ExecutionPolicy Bypass -File .\itrix-backend-fixes-aug12\INSTALL.ps1
```

Then:

```powershell
python -m pytest -q                                  # expect 1156 passed / 0 failed
python manage.py check                               # expect 0 issues
python manage.py makemigrations --check --dry-run     # expect "No changes detected"
```

The installer prints the exact `git add` line for the 17 files. **Do not use
`git add -A`** — this repo is CRLF and about 870 files show as modified from
line-ending churn alone, which would bury the real change in an unreviewable diff.

## Validation performed here

Measured against a pristine copy of the same commit (`77bdc64`), same interpreter:

| Gate | Baseline | This package |
|---|---|---|
| `pytest -q` | 1114 passed / 0 failed | **1156 passed / 0 failed** (+42, 0 regressions) |
| `manage.py check` | 0 issues | 0 issues |
| `makemigrations --check` | clean | clean |
| `flake8 apps/ api/` | 31 findings | **byte-identical, 31** |
| `flake8` on the new tests | — | clean |

All 17 payload files are CRLF with zero bare LFs, and the suite was re-run after
line-ending normalisation, so the bytes in the zip are the bytes that passed.

---

## 1. Staff replies were invisible in transcripts

`apps/conversations/services/ingest.py`

`ingest_team_message()` created the `Message` with **no `thread` and no `seq`**, while its
sibling `ingest_agent_message()` resolved both. Every transcript read — the visitor's,
the portal's, the cockpit's — queries **by thread**, so a staff reply was persisted
correctly and rendered nowhere.

Now resolves the thread (still nullable, so the shipped review and client-page
conversations that predate the spine keep working) and allocates `seq`. The sequence
half matters independently: a message left at 0 sorts *before* the visitor's first turn
in any ordered read, and `seq` is what the realtime client uses to detect a gap.

## 2. Lead actions returned stale notes and activity

`apps/leads/views.py`

The viewset queryset carries `prefetch_related("notes", "activities", "meetings")`.
`get_object()` fills those caches *before* the action runs, so serialising the same
instance afterwards rendered the cache — without the note just added. The operator saw
their note missing and pressed the button again.

`_detail_response` now refetches by pk. Fixed at that one choke-point rather than in
each action, so no future action can reintroduce it by forgetting.

## 3. Lead assignment silently overrode

`apps/leads/services/lead_updater.py`, `apps/leads/views.py`, `apps/leads/serializers.py`

`lead.owner = owner; lead.save()` is a read-modify-write across a round trip. Two
operators who both loaded the board each saw `owner is None`, both saved, and the second
won — with **nothing on screen to say so**. The loser got a 200 carrying the winner's
name.

The lead is now claimed with a single conditional `UPDATE`
(`filter(pk=..., owner__isnull=True).update(...)`); the database decides and the row
count tells us whether we won. An already-owned lead returns **409** with
`currentOwner` and a hint. Deliberate reassignment is `force: true` — naming it puts
"this was a takeover" in the request rather than leaving it to be inferred.

Re-assigning to the same owner is idempotent and never 409s. The activity row is written
only on a write that landed: a timeline that logged losing attempts would show owner
changes that never happened.

`assign_owner()` returns an `AssignResult` now. The default (`only_if_unowned=False`) is
the old behaviour, so no existing caller changed meaning.

## 4. The cockpit boards capped at 500 with no offset

`apps/cockpit/services/threads.py`, `apps/cockpit/services/customers.py`,
`apps/cockpit/views.py`

`MAX_LIMIT = 500` with `[:limit]` and no offset meant the 501st-oldest row could not be
reached by any request. A cap on page *size* is a scanning decision; a cap with no offset
is data loss.

Both services gained `page(limit=, offset=)` returning
`{results, total, limit, offset, hasMore}`. `rows()` and `results()` remain as thin reads
of it, so existing callers and tests keep their shape and there is only one query
implementation. Thread ordering gained `id` as a final tiebreak — an unstable sort under
paging shows one row twice and skips another.

`count` keeps its existing meaning (rows in *this* response), so a deployed dashboard is
unaffected; `total`, `offset` and `hasMore` are additive.

**One honest limitation, named in the payload.** Customer health is computed in Python by
`health_calculator.calculate`, not stored, so the database cannot sort by it. "Worst
first" has therefore always meant "worst first within what was fetched" — the old
`[:200]` had the same property. Paging makes it visible rather than introducing it, so
the response now carries `ordering: "worst_first_within_page"` and the page order is a
stable `-created_at, id`. **A dashboard must not read row 1 of page 1 as the most at-risk
customer overall.** Sorting the whole book worst-first would require computing health for
every active client on every board load; if that becomes wanted, it belongs behind a
stored/denormalised health column rather than a bigger query.

## 5. The support queue was read-only

`apps/cockpit/services/support_queue.py`, `apps/cockpit/views.py`, `apps/cockpit/urls.py`

The queue existed to make §18.7 legible — an operator who cannot see the blocking request
experiences the expansion suppression as obstruction and goes looking for the override.
But the row that *explained* the block could not *end* it.

Two actions, both `IsNotViewer` on top of the team gate:

```
POST cockpit/support/queue/{id}/assign/    {"owner": "me" | "<email|name|id>" | null}
POST cockpit/support/queue/{id}/resolve/   {"note": "how it was resolved"}
```

- **assign** is *not* assign-if-unowned, unlike lead assignment. A support request is not
  a commercial claim; handing one to whoever is on shift is normal, and requiring a force
  flag would train people to always send it. Clearing the owner is allowed — an unowned
  request is an honest state the queue displays. Taking an open request stamps
  `first_response_at` if nothing had responded yet, because the SLA clock measures against
  it and an operator should not have to remember.
- **resolve** requires a note, enforced **in the service, not the view**, so a direct API
  call cannot close a customer's problem without saying how — the same placement, for the
  same reason, as the attachment release reason. Idempotent: the first close is when it
  stopped blocking the customer, and that is the timestamp health reads.

Neither action touches `blocking` or `customer_confirmed_resolved`. The first is the
customer's situation and the field NBA suppression reads — an operator who could clear it
could unblock their own commercial action by relabelling somebody else's problem. The
second is the customer's answer to "did this actually fix it?", and staff answering for
them would erase the most useful signal on the row.

The queue response now names `actions: ["assign", "resolve"]`, so the dashboard renders
the buttons the API honours rather than a hard-coded guess that drifts.

## 6. `settings/notifications/` returned 404

`api/v1/urls.py`

`apps.settings` has been in `INSTALLED_APPS` with a complete `urls.py` (two routes) the
whole time. The router never `include()`d it, so both endpoints 404'd and the
notification-preference screen had nothing to talk to. One line added; `"settings"` added
to the index's `live_groups`.

## 7. Staff→visitor files, and the thread↔conversation link on the wire

`apps/attachments/views.py`, `apps/attachments/permissions.py`, `apps/agents/views.py`,
`apps/conversations/serializers.py`, `apps/conversations/services/fan_out.py`

**Sending.** The upload and status-poll views now also accept a team JWT. `ConsoleMessageView`
accepts `attachmentIds`, links them **before** the broadcast (linking after would deliver
a message whose files appear only on the next fetch — which reads as "they said they
attached something and there is nothing there"), and returns `threadId`,
`attachmentsLinked` and `attachmentsRejected`. A file-only reply is accepted; an empty
fileless one is still refused.

Attachment ids are scoped to **this conversation's thread**. An id in a request body is
not authorization, and a console operator must not be able to staple another customer's
document to a turn by pasting its id.

Team uploads are stamped `uploaded_by_kind="team"`, derived from *who uploaded* rather
than who owns the thread. That distinction matters twice: the excerpt selector fences
visitor uploads as untrusted model input, and the attachment review queue exists to look
at what visitors sent us.

**A bug this package found in its own first draft — worth reading before you touch
`is_team_caller`.** The draft asked `core.permissions._is_active_team_member`, which is
`authenticated and active`. That is a correct team check on a view whose only
authenticator is team SimpleJWT, because `request.user` can only be a team `User` there.
On *this* view `ClientJWTAuthentication` also runs, so `request.user` may be a **Client** —
and a Client is authenticated and active. Every signed-in customer would have passed as
staff and could have attached a file to **any** thread, including another customer's. The
existing `test_a_stranger_cannot_stage_a_file_against_someone_elses_thread` failed and
named it. `is_team_caller` now checks the type, excludes `Client` explicitly, and requires
a team role. `tests/test_attachments/test_team_upload_plane.py` pins all of it, including
that staff still cannot download a visitor's file through the visitor endpoint.

`staff_may_attach` is deliberately a separate predicate rather than a branch inside
`owns_thread`: widening the latter would have widened `CanDownloadAttachment` with it, and
that gate exists precisely so another subject cannot reach a visitor's bytes.

**Mapping.** `Conversation` and `Thread` are separate models and nothing bridged them on
the wire. The console row named a conversation while every row-level cockpit resource is
keyed by thread, so an operator reading a conversation could not open its board row.
`threadId` is now on `TeamConversationSummarySerializer` and on **both**
`broadcast_message` frames (`message.final` and `message.under_review`). Null for the
pre-spine conversations — which is the truth there, and distinguishable from an omitted
field.

---

## Not changed, and why

**`db.sqlite3`** — nothing to remove. It is not tracked, has no history in the repo, and
is already ignored twice in `.gitignore` (lines 61 and 246). If one exists on your
machine it is an untracked artefact of a local `manage.py` run; delete it locally.

## Two pre-existing issues noticed while in here (not touched — out of scope)

- **The citation trail is empty everywhere.** Six agents extract `c.get("chunk_id")` but
  `KnowledgeRetriever` emits the key `"id"`, so `AgentRun.chunk_ids`,
  `Message.cited_chunk_ids`, the cockpit's `chunkIds` and the result page's `chunk_count`
  are always blank. Grounding itself works — the chunks do reach the prompt — but it
  cannot be audited. One-word fix, in six places, and it deserves its own change.
- **`with_attachment_context()` has no callers.** Extraction and excerpt selection both
  work, and nothing puts the result in front of the model, so uploaded documents never
  reach a reply. This is the second half of the upload work and is queued next.
