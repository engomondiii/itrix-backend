#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST_ROOT="$(pwd)"
if [[ ! -f "$DEST_ROOT/manage.py" ]]; then
  echo "ERROR: run this from the itrix-backend root (the folder with manage.py)." >&2
  exit 1
fi
STAMP="$(date +%Y%m%d%H%M%S)"
FILES=( "apps/result_page/services/result_generator.py" )
echo "itriX backend fix (v4.0.4 — instant client page) → ${#FILES[@]} file(s) into: $DEST_ROOT"
for rel in "${FILES[@]}"; do
  src="$SRC_DIR/$rel"; dest="$DEST_ROOT/$rel"
  [[ -f "$src" ]] || { echo "  ! missing $rel"; continue; }
  mkdir -p "$(dirname "$dest")"
  [[ -f "$dest" ]] && { cp -p "$dest" "$dest.bak-$STAMP"; echo "  • backed up  $rel"; }
  cp -f "$src" "$dest"; echo "  ✓ applied    $rel"
done
echo "Done. Restart the backend (gunicorn/daphne)."
