# =============================================================================
#  itriX backend - fix set, 2026-08-12
#  INSTALL.ps1
# =============================================================================
#  Run from the ROOT of the itrix-backend repository:
#
#      Expand-Archive .\itrix-backend-fixes-aug12.zip -DestinationPath . -Force
#      powershell -ExecutionPolicy Bypass -File .\itrix-backend-fixes-aug12\INSTALL.ps1
#
#  What it does, in order:
#      1. verifies it is being run against itrix-backend (guard)
#      2. backs up every file it is about to overwrite, into a timestamped folder
#      3. copies 17 files (15 modified, 2 new tests)
#      4. verifies each copy landed, by path AND by byte length
#      5. clears stale __pycache__ for the touched packages
#      6. prints the exact `git add` command for the 17 files
#
#  It does NOT run migrations (there are none in this set - no model changed),
#  does NOT touch .env, and does NOT run pip. It is idempotent: running it twice
#  is harmless and produces a second backup folder.
#
#  ASCII only, by policy: Windows PowerShell 5.1 reads a BOM-less UTF-8 .ps1 as
#  ANSI and renders any non-ASCII character as mojibake in the console.
# =============================================================================

[CmdletBinding()]
param(
    # Where the payload/ folder is. Defaults to this script's own directory.
    [string] $PayloadRoot = "",
    # Where the repo is. Defaults to the current directory.
    [string] $RepoRoot = "",
    # Skip the repository guard.
    [switch] $Force
)

$ErrorActionPreference = "Stop"

# -- Path helpers -------------------------------------------------------------
# .NET rather than Split-Path / New-Item, deliberately:
#   * Split-Path -LiteralPath is its own parameter set and does NOT accept
#     -Parent or -Leaf, which fails at runtime.
#   * New-Item -Path has no -LiteralPath at all and treats [ ] as a wildcard
#     character class - which silently skips bracketed dynamic-route paths.
function ParentOf([string] $p) { return [System.IO.Path]::GetDirectoryName($p) }
function EnsureDir([string] $p) { [void][System.IO.Directory]::CreateDirectory($p) }

# -- Resolve roots ------------------------------------------------------------
# $PSScriptRoot has come back empty in this environment before (2026-08-07), so
# it is not trusted on its own.
$scriptDir = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($scriptDir)) {
    $scriptDir = ParentOf $MyInvocation.MyCommand.Path
}
if ([string]::IsNullOrWhiteSpace($scriptDir)) { $scriptDir = (Get-Location).Path }

if ([string]::IsNullOrWhiteSpace($PayloadRoot)) {
    $PayloadRoot = Join-Path $scriptDir "payload"
}
if ([string]::IsNullOrWhiteSpace($RepoRoot)) {
    $RepoRoot = (Get-Location).Path
}

Write-Host ""
Write-Host "itriX backend fix set - 2026-08-12" -ForegroundColor Cyan
Write-Host "  repo:    $RepoRoot"
Write-Host "  payload: $PayloadRoot"
Write-Host ""

if (-not (Test-Path -LiteralPath $PayloadRoot)) {
    throw "Payload folder not found: $PayloadRoot"
}

# -- 1. Repository guard ------------------------------------------------------
$marker = Join-Path $RepoRoot "manage.py"
$appsDir = Join-Path $RepoRoot "apps"
if (-not $Force) {
    if (-not (Test-Path -LiteralPath $marker) -or -not (Test-Path -LiteralPath $appsDir)) {
        throw "This does not look like the itrix-backend repo root (no manage.py / apps). Run it from the repo root, or pass -Force."
    }
    $cockpit = Join-Path $RepoRoot "apps\cockpit\services\support_queue.py"
    if (-not (Test-Path -LiteralPath $cockpit)) {
        throw "apps\cockpit\services\support_queue.py is missing - this package expects Backend v7.1 Phase 2 or later. Pass -Force to override."
    }
}

# -- 2/3/4. Back up, copy, verify --------------------------------------------
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $RepoRoot ".backend-fixes-aug12-backup-$stamp"

$files = Get-ChildItem -LiteralPath $PayloadRoot -Recurse -File
if ($files.Count -eq 0) { throw "Payload contains no files." }

$installed = 0
$added = 0
$backedUp = 0
$failures = @()

foreach ($f in $files) {
    $rel = $f.FullName.Substring($PayloadRoot.Length).TrimStart([char]92, [char]47)
    $dest = Join-Path $RepoRoot $rel

    if (Test-Path -LiteralPath $dest) {
        $bdest = Join-Path $backupDir $rel
        EnsureDir (ParentOf $bdest)
        Copy-Item -LiteralPath $dest -Destination $bdest -Force
        $backedUp++
        $tag = "MOD"
    } else {
        $added++
        $tag = "ADD"
    }

    EnsureDir (ParentOf $dest)
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force

    # Verify by existence AND size. A copy that silently wrote nothing is the
    # failure mode a bare Test-Path would report as success.
    if (-not (Test-Path -LiteralPath $dest)) {
        $failures += "MISSING after copy: $rel"
        continue
    }
    $srcLen = (Get-Item -LiteralPath $f.FullName).Length
    $dstLen = (Get-Item -LiteralPath $dest).Length
    if ($srcLen -ne $dstLen) {
        $failures += "SIZE MISMATCH: $rel ($srcLen vs $dstLen)"
        continue
    }

    $installed++
    Write-Host ("  {0}  {1}" -f $tag, $rel)
}

if ($failures.Count -gt 0) {
    Write-Host ""
    Write-Host "INSTALL FAILED - the following files did not land cleanly:" -ForegroundColor Red
    foreach ($x in $failures) { Write-Host "  $x" -ForegroundColor Red }
    if (Test-Path -LiteralPath $backupDir) {
        Write-Host ""
        Write-Host "Your originals are in: $backupDir" -ForegroundColor Yellow
    }
    throw "Aborting: $($failures.Count) file(s) failed verification."
}

# -- 5. Clear stale bytecode -------------------------------------------------
# A .pyc for a module whose .py was just replaced is not used by CPython (the
# hash/mtime check catches it), but a stale __pycache__ inside a package that
# gained a file has confused test collection before. Cheap to clear.
$pycTargets = @("apps", "api", "tests")
foreach ($t in $pycTargets) {
    $full = Join-Path $RepoRoot $t
    if (Test-Path -LiteralPath $full) {
        Get-ChildItem -LiteralPath $full -Recurse -Directory -Filter "__pycache__" -ErrorAction SilentlyContinue |
            ForEach-Object { Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

# -- Ignore the backup folder ------------------------------------------------
$gitignore = Join-Path $RepoRoot ".gitignore"
if (Test-Path -LiteralPath $gitignore) {
    $existing = Get-Content -LiteralPath $gitignore -Raw
    $patterns = @(".backend-fixes-aug12-backup-*", "itrix-backend-fixes-aug12/")
    foreach ($p in $patterns) {
        if ($existing -notlike "*$p*") {
            Add-Content -LiteralPath $gitignore -Value $p
            Write-Host "  .gitignore += $p"
        }
    }
}

# -- 6. Report ---------------------------------------------------------------
Write-Host ""
Write-Host "Installed $installed file(s): $added added, $backedUp modified." -ForegroundColor Green
if ($backedUp -gt 0) { Write-Host "Backup: $backupDir" }
Write-Host ""
Write-Host "NEXT STEPS" -ForegroundColor Cyan
Write-Host "  1. Run the suite (expect 1156 passed / 0 failed):"
Write-Host "       python -m pytest -q"
Write-Host "  2. Sanity checks:"
Write-Host "       python manage.py check"
Write-Host "       python manage.py makemigrations --check --dry-run"
Write-Host "  3. Stage ONLY these files. Do NOT use 'git add -A' - this repo is"
Write-Host "     CRLF and ~870 files show as modified from line-ending churn"
Write-Host "     alone, which would bury the real change in an unreviewable diff."
Write-Host ""

$rels = @()
foreach ($f in $files) {
    $rels += $f.FullName.Substring($PayloadRoot.Length).TrimStart([char]92, [char]47).Replace([char]92, [char]47)
}
Write-Host ("git add " + ($rels -join " ")) -ForegroundColor Yellow
Write-Host ""
Write-Host "  4. Commit and redeploy the backend. No migrations are needed:"
Write-Host "     nothing in this set changed a model."
Write-Host ""
