"""Client serializers — invite claim I/O and the client identity shape."""

from __future__ import annotations

from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers

from apps.clients.password_policy import validate_client_password

from apps.clients.models import Client


class ClientIdentitySerializer(serializers.ModelSerializer):
    """The client profile the portal renders (camelCase; Surface 1 client plane)."""

    leadId = serializers.CharField(source="lead_id", read_only=True)
    fullName = serializers.CharField(source="full_name", allow_blank=True)
    ndaSigned = serializers.BooleanField(source="nda_signed", read_only=True)
    # v7.2 — a fact about the holder's OWN address, so it is theirs to see. It is not a
    # disclosure about anybody else. `itrix-web` reads a MISSING key as "unknown" rather than
    # as unconfirmed, which is why this is the only place it can come from.
    emailVerified = serializers.SerializerMethodField()

    class Meta:
        model = Client
        fields = [
            "id",
            "leadId",
            "email",
            "fullName",
            "organization",
            "role",
            "ndaSigned",
            "emailVerified",
        ]
        read_only_fields = ["id", "leadId", "email", "ndaSigned", "emailVerified"]

    def get_emailVerified(self, obj) -> bool:
        return getattr(obj, "email_verified_at", None) is not None


class InviteClaimRequestSerializer(serializers.Serializer):
    """Body for ``POST accounts/invite/{token}/claim/``."""

    email = serializers.EmailField(required=False, allow_null=True, allow_blank=True)
    password = serializers.CharField(required=False, allow_null=True, allow_blank=True, write_only=True)
    full_name = serializers.CharField(required=False, allow_blank=True, default="")
    organization = serializers.CharField(required=False, allow_blank=True, default="")
    role = serializers.CharField(required=False, allow_blank=True, default="")
    # v7.2 — the instrument versions the visitor was SHOWN travel with the claim, and
    # `claim_invite()` writes the record inside the transaction that creates the Client
    # (R62). The surface used to POST them separately to `portal/legal/assent/` first, which
    # produced a SECOND record because the backend has recorded one in-transaction since
    # v7.1 Phase 3.
    assent = serializers.ListField(child=serializers.DictField(), required=False, default=list)

    def validate_password(self, value: str | None):
        if not value:
            return value
        try:
            return validate_client_password(value)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages)) from exc


class InviteClaimResponseSerializer(serializers.Serializer):
    """Response for a successful claim (client profile + password-set flag + tokens)."""

    client = ClientIdentitySerializer()
    requiresPasswordSet = serializers.BooleanField()


class PasswordSetRequestSerializer(serializers.Serializer):
    """Body for ``POST client/auth/password/set/`` (first-time / reset)."""

    token = serializers.CharField()
    password = serializers.CharField(write_only=True)
    access = serializers.CharField(required=False)
    refresh = serializers.CharField(required=False)

    def validate_password(self, value: str):
        try:
            return validate_client_password(value)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages)) from exc


# ─────────────────────────────────────────────────────────────────────────────
# Phase 2 — client-plane auth + portal payload serializers
# ─────────────────────────────────────────────────────────────────────────────
class ClientLoginRequestSerializer(serializers.Serializer):
    """Body for POST client/auth/login/."""

    email = serializers.EmailField()
    password = serializers.CharField(write_only=True, trim_whitespace=False)


class ClientTokenRefreshRequestSerializer(serializers.Serializer):
    """Body for POST client/auth/token/refresh/."""

    refresh = serializers.CharField()


class PortalOverviewSerializer(serializers.Serializer):
    """The personalized portal workspace payload (PortalOverview)."""

    client = ClientIdentitySerializer()
    stage = serializers.CharField()            # journey state (client-facing label)
    unreadMessages = serializers.IntegerField()
    briefingAvailable = serializers.BooleanField()
    nextSteps = serializers.ListField(child=serializers.CharField())
    ndaSigned = serializers.BooleanField()
    lastUpdated = serializers.DateTimeField(allow_null=True)


class PortalDocumentSerializer(serializers.Serializer):
    title = serializers.CharField()
    disclosure = serializers.CharField()
    href = serializers.CharField(allow_blank=True)
    locked = serializers.BooleanField()


class PortalDocumentFolderSerializer(serializers.Serializer):
    """One folder of documents, as the Documents screen renders it."""

    folder = serializers.CharField()
    documents = PortalDocumentSerializer(many=True)


class PortalDataRoomSerializer(serializers.Serializer):
    """
    PortalDataRoom — NDA-aware document listing.

    ── SHAPE FIX (2026-08-10) ───────────────────────────────────────────────
    The screen renders FOLDERS (`openFolders` + `dataRoomFolders`, per
    portal.types.PortalDataRoom); this serializer used to emit a flat
    `documents` list, so `data.openFolders.map(...)` crashed the Documents page
    with "Cannot read properties of undefined (reading 'map')" the first time a
    real client opened it. The payload now matches what is rendered.
    """

    ndaSigned = serializers.BooleanField()
    # Explicit server authorization, deliberately distinct from NDA state.
    dataRoomAuthorized = serializers.BooleanField()
    openFolders = PortalDocumentFolderSerializer(many=True)
    dataRoomFolders = PortalDocumentFolderSerializer(many=True)
    ndaContextPresent = serializers.BooleanField(default=False)
    ndaProblemContext = serializers.CharField(required=False, allow_blank=True, default="")
    ndaWorkloadContext = serializers.CharField(required=False, allow_blank=True, default="")
    ndaDesiredOutcome = serializers.CharField(required=False, allow_blank=True, default="")
    ndaDiscussionReason = serializers.CharField(required=False, allow_blank=True, default="")


class PortalEvaluationSerializer(serializers.Serializer):
    exists = serializers.BooleanField()
    kind = serializers.CharField(default="alpha_compute")
    stage = serializers.CharField(allow_blank=True)
    astopStage = serializers.CharField(required=False, allow_blank=True, default="")
    kpis = serializers.ListField(child=serializers.DictField(), default=list)
    reportHref = serializers.CharField(allow_blank=True)
    ttfvSeconds = serializers.IntegerField(required=False, allow_null=True, default=None)
    verifiedValue = serializers.JSONField(required=False, default=dict)
    customerFeeStatus = serializers.CharField(required=False, allow_blank=True, default="")
    finalAssessmentFee = serializers.DecimalField(max_digits=14, decimal_places=2, required=False, allow_null=True, default=None)


class PortalPoCSerializer(serializers.Serializer):
    exists = serializers.BooleanField()
    stage = serializers.CharField(allow_blank=True)
    milestones = serializers.ListField(child=serializers.DictField(), default=list)
    successCriteria = serializers.ListField(child=serializers.DictField(), default=list)


class PortalNotificationPrefsSerializer(serializers.Serializer):
    """The four notification switches (§68). Keys mirror PortalNotificationPrefs."""

    newTeamMessage = serializers.BooleanField(required=False)
    reviewUpdated = serializers.BooleanField(required=False)
    evalOrPocStatus = serializers.BooleanField(required=False)
    documentShared = serializers.BooleanField(required=False)


class PortalSettingsProfileSerializer(serializers.Serializer):
    """The editable profile block inside PortalSettings."""

    fullName = serializers.CharField(allow_blank=True, allow_null=True, required=False)
    email = serializers.EmailField(read_only=True)
    organization = serializers.CharField(allow_blank=True, allow_null=True, required=False)
    role = serializers.CharField(allow_blank=True, allow_null=True, required=False)


class PortalSettingsPatchSerializer(serializers.Serializer):
    """
    PATCH portal/settings/ — the nested write shape the Settings screen sends
    ({profile: {...}} and/or {notifications: {...}}).

    ── SHAPE FIX (2026-08-10) ───────────────────────────────────────────────
    The screen renders {profile, team, notifications} (portal.types
    .PortalSettings); the old serializer was a flat profile, so `data.team.map`
    and the notification switches crashed the Settings page. GET now returns
    the nested shape (built in the view) and PATCH accepts it.
    """

    profile = PortalSettingsProfileSerializer(required=False)
    notifications = PortalNotificationPrefsSerializer(required=False)
