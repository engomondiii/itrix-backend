# itriX Backend Fix v4.0.5 — expose `usedAi` so the client page can auto-update

## Purpose
Adds the signal the frontend needs to auto-swap the deterministic client page for the
AI-enriched one WITHOUT a manual reload.

## Files
- `apps/result_page/serializers.py` — adds `usedAi` (from the model's `used_ai`) to the
  client-page payload. It's `false` on the instant deterministic page and flips `true`
  once the background AI build has enriched + persisted the result page.
- `apps/result_page/services/result_generator.py` — the v4.0.4 instant-client-page build
  (deterministic on the synchronous GET path; AI enrichment stays in the background). This
  is included so the backend is a consistent complete set even if v4.0.4 wasn't applied
  from a zip. (If you already deployed v4.0.4 via git, this file is identical/compatible.)

## Apply
```bash
cd /path/to/itrix-backend
unzip -o itrix-backend-fix.zip -d /tmp/befix
bash /tmp/befix/backend_fix/APPLY_BACKEND_FIX.sh
```
Restart the backend.

## Verified
- Client-page payload returns `usedAi:false` initially, `usedAi:true` after the background
  build sets `used_ai=True` — the exact transition the frontend polls for.
- Client-page GET stays instant (deterministic on the request path).
